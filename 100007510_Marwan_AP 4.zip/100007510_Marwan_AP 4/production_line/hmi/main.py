"""
main.py
Ink Marker Manufacturing Production Line – HMI Entry Point
Pygame-based Human Machine Interface.

Run:  python main.py
"""

import os
import sys
import time
import pygame

# Allow both:
#   python production_line/hmi/main.py
#   python -m production_line.hmi.main
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from production_line.backend.production_logic import ProductionLine, MachineState
from production_line.backend.influx_client import get_writer, shutdown
from production_line.hmi.ui_components import (
    Button, StageCard, StatsPanel, StateBanner,
    C
)

# ── Window Config ─────────────────────────────────────────────────────────────
WIN_W, WIN_H = 1100, 700
FPS          = 30
TITLE        = "Ink Marker Manufacturing Production Line  |  SRH Advanced Programming 2026"

# ── Auto-advance delay after COMPLETE (seconds) ───────────────────────────────
AUTO_NEXT_DELAY = 2.5


class HMIApp:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption(TITLE)
        self.screen  = pygame.display.set_mode((WIN_W, WIN_H))
        self.clock   = pygame.time.Clock()
        self.running = True

        # Core objects
        self.line   = ProductionLine()
        self.writer = get_writer()

        # Auto-advance timer
        self._complete_timer: float = 0.0
        self._auto_advance   = False

        # Metrics write throttle (write every 2 s)
        self._last_metric_write = 0.0
        self._metric_interval   = 2.0

        # Fonts
        self._font_title = pygame.font.SysFont("segoeui", 16, bold=True)
        self._font_small = pygame.font.SysFont("segoeui", 12)

        self._build_layout()

    # ------------------------------------------------------------------ #
    #  Layout                                                              #
    # ------------------------------------------------------------------ #

    def _build_layout(self):
        PAD = 14

        # ── Title bar ──────────────────────────────────────────────────
        self._title_rect = pygame.Rect(0, 0, WIN_W, 44)

        # ── State banner ───────────────────────────────────────────────
        self._banner = StateBanner(
            pygame.Rect(PAD, 50, WIN_W - 280 - PAD * 3, 58)
        )

        # ── Stage cards (stacked vertically, left column) ──────────────
        card_x     = PAD
        card_w     = WIN_W - 280 - PAD * 3
        card_h     = 72
        card_gap   = 10
        card_top   = 120

        self._stage_cards: list[StageCard] = []
        for i, stage in enumerate(self.line.stages):
            rect = pygame.Rect(
                card_x,
                card_top + i * (card_h + card_gap),
                card_w,
                card_h,
            )
            self._stage_cards.append(
                StageCard(rect, stage.id, stage.name, stage.description)
            )

        # ── Stats panel (right column) ─────────────────────────────────
        stats_x = WIN_W - 280 - PAD
        self._stats = StatsPanel(
            pygame.Rect(stats_x, 50, 280, WIN_H - 180)
        )

        # ── Buttons (bottom row) ───────────────────────────────────────
        btn_y   = WIN_H - 100
        btn_h   = 52
        btn_gap = 12
        btn_w   = (WIN_W - PAD * 2 - btn_gap * 3) // 4

        self._btn_start = Button(
            pygame.Rect(PAD, btn_y, btn_w, btn_h),
            "START",
            color=C["green_dark"], hover_color=C["green"],
            callback=self._on_start,
        )
        self._btn_stop = Button(
            pygame.Rect(PAD + btn_w + btn_gap, btn_y, btn_w, btn_h),
            "STOP",
            color=C["yellow_dark"], hover_color=C["yellow"],
            text_color=C["bg"],
            callback=self._on_stop,
        )
        self._btn_reset = Button(
            pygame.Rect(PAD + (btn_w + btn_gap) * 2, btn_y, btn_w, btn_h),
            "RESET",
            color=C["blue_dark"], hover_color=C["blue"],
            callback=self._on_reset,
        )
        self._btn_estop = Button(
            pygame.Rect(PAD + (btn_w + btn_gap) * 3, btn_y, btn_w, btn_h),
            "E-STOP",
            color=C["red_dark"], hover_color=C["red"],
            callback=self._on_estop,
        )

        self._all_buttons = [
            self._btn_start, self._btn_stop,
            self._btn_reset, self._btn_estop,
        ]

    # ------------------------------------------------------------------ #
    #  Button Callbacks                                                    #
    # ------------------------------------------------------------------ #

    def _on_start(self):
        state = self.line.state
        if state == MachineState.IDLE or state == MachineState.STOPPED:
            self.line.start()
        elif state == MachineState.COMPLETE:
            self.line.start_new_cycle()
        elif state == MachineState.FAULTED:
            self.line.acknowledge_fault()
        self._auto_advance = False

    def _on_stop(self):
        self.line.stop()
        self._auto_advance = False

    def _on_reset(self):
        self.line.reset()
        self._auto_advance = False
        self._complete_timer = 0.0

    def _on_estop(self):
        self.line.emergency_stop()
        self._auto_advance = False

    # ------------------------------------------------------------------ #
    #  Main Loop                                                           #
    # ------------------------------------------------------------------ #

    def run(self):
        while self.running:
            delta = self.clock.tick(FPS) / 1000.0   # seconds since last frame

            self._handle_events()
            self._update(delta)
            self._draw()
            pygame.display.flip()

        shutdown()
        pygame.quit()
        sys.exit()

    # ------------------------------------------------------------------ #
    #  Events                                                              #
    # ------------------------------------------------------------------ #

    def _handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.running = False
                elif event.key == pygame.K_s:
                    self._on_start()
                elif event.key == pygame.K_x:
                    self._on_stop()
                elif event.key == pygame.K_r:
                    self._on_reset()
                elif event.key == pygame.K_e:
                    self._on_estop()
            for btn in self._all_buttons:
                btn.handle_event(event)

    # ------------------------------------------------------------------ #
    #  Update                                                              #
    # ------------------------------------------------------------------ #

    def _update(self, delta: float):
        self.line.update(delta)

        # Auto-advance: after COMPLETE pause then start next cycle
        if self.line.state == MachineState.COMPLETE:
            if not self._auto_advance:
                self._auto_advance   = True
                self._complete_timer = 0.0
            self._complete_timer += delta
            if self._complete_timer >= AUTO_NEXT_DELAY:
                self.line.start_new_cycle()
                self._auto_advance   = False
                self._complete_timer = 0.0

        # Write metrics to InfluxDB every N seconds
        now = time.time()
        if now - self._last_metric_write >= self._metric_interval:
            self.writer.put(self.line.get_metrics())
            self._last_metric_write = now

        # Sync stage cards
        for i, card in enumerate(self._stage_cards):
            stage = self.line.stages[i]
            card.update(
                status    = stage.status.value,
                progress  = stage.progress,
                fault_msg = stage.fault_message,
            )

        # Button enable states
        state = self.line.state
        self._btn_start.enabled = state not in (
            MachineState.RUNNING, MachineState.EMERGENCY
        )
        self._btn_stop.enabled  = state == MachineState.RUNNING
        self._btn_reset.enabled = state != MachineState.RUNNING
        self._btn_estop.enabled = state not in (
            MachineState.IDLE, MachineState.EMERGENCY
        )

    # ------------------------------------------------------------------ #
    #  Draw                                                                #
    # ------------------------------------------------------------------ #

    def _draw(self):
        self.screen.fill(C["bg"])
        self._draw_title()

        metrics = self.line.get_metrics()

        # State banner
        self._banner.draw(
            self.screen,
            state        = self.line.state.value,
            fault_msg    = self.line.active_fault,
            current_stage = metrics["current_stage"],
        )

        # Stage cards
        for card in self._stage_cards:
            card.draw(self.screen)

        # Stats panel
        self._stats.draw(self.screen, metrics, self.writer.connected)

        # Buttons
        for btn in self._all_buttons:
            btn.draw(self.screen)

        # Hotkey hint bar
        self._draw_hints()

        # Auto-advance countdown
        if self._auto_advance:
            remaining = max(0, AUTO_NEXT_DELAY - self._complete_timer)
            msg = f"Next cycle in {remaining:.1f}s ...  (or press START)"
            surf = self._font_small.render(msg, True, C["blue"])
            self.screen.blit(surf, (14, WIN_H - 114))

    def _draw_title(self):
        pygame.draw.rect(self.screen, C["panel"], self._title_rect)
        pygame.draw.line(
            self.screen, C["border"],
            (0, self._title_rect.bottom),
            (WIN_W, self._title_rect.bottom), 1
        )
        title_surf = self._font_title.render(
            "Ink Marker Manufacturing Production Line", True, C["text_title"]
        )
        sub_surf = self._font_small.render(
            "SRH Advanced Programming Project 2026  |  "
            "Hotkeys:  S = Start   X = Stop   R = Reset   E = E-Stop",
            True, C["text_dim"]
        )
        self.screen.blit(title_surf, (14, 6))
        self.screen.blit(sub_surf, (14, 28))

    def _draw_hints(self):
        hint = self._font_small.render(
            "Keyboard shortcuts:  S = Start   X = Stop   R = Reset   E = Emergency Stop   ESC = Quit",
            True, C["text_dim"],
        )
        self.screen.blit(hint, (14, WIN_H - 18))


# ── Entry Point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    app = HMIApp()
    app.run()
