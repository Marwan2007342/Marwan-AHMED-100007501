"""
ui_components.py
Reusable Pygame UI widgets for the Ink Marker Production Line HMI.
"""

import pygame
from dataclasses import dataclass
from typing import Callable, Optional, Tuple

# ── Colour Palette ────────────────────────────────────────────────────────────
C = {
    "bg":           (18,  18,  24),
    "panel":        (28,  28,  38),
    "border":       (55,  55,  75),
    "text":         (220, 220, 230),
    "text_dim":     (120, 120, 140),
    "text_title":   (255, 255, 255),

    "green":        (50,  200, 100),
    "green_dark":   (30,  120,  60),
    "yellow":       (255, 200,  40),
    "yellow_dark":  (160, 120,  10),
    "red":          (220,  55,  55),
    "red_dark":     (130,  25,  25),
    "blue":         (60,  140, 240),
    "blue_dark":    (30,   70, 150),
    "grey":         (70,   70,  85),
    "grey_dark":    (40,   40,  50),
    "orange":       (240, 140,  30),
    "orange_dark":  (150,  80,  10),
    "white":        (255, 255, 255),

    # Machine state colours
    "IDLE":           (70,  70,  85),
    "RUNNING":        (50, 200, 100),
    "STOPPED":        (255,200,  40),
    "FAULTED":        (220, 55,  55),
    "EMERGENCY STOP": (220, 55,  55),
    "CYCLE COMPLETE": (60, 140, 240),
}


def rounded_rect(surface: pygame.Surface, color: Tuple, rect: pygame.Rect,
                 radius: int = 10, border: int = 0,
                 border_color: Tuple = (255, 255, 255)):
    pygame.draw.rect(surface, color, rect, border_radius=radius)
    if border > 0:
        pygame.draw.rect(surface, border_color, rect, width=border, border_radius=radius)


# ── Button ────────────────────────────────────────────────────────────────────

class Button:
    def __init__(self, rect: pygame.Rect, label: str,
                 color: Tuple, hover_color: Tuple,
                 text_color: Tuple = C["white"],
                 font_size: int = 18,
                 callback: Optional[Callable] = None,
                 enabled: bool = True,
                 radius: int = 8):
        self.rect        = rect
        self.label       = label
        self.color       = color
        self.hover_color = hover_color
        self.text_color  = text_color
        self.callback    = callback
        self.enabled     = enabled
        self.radius      = radius
        self._hovered    = False
        self._font       = pygame.font.SysFont("segoeui", font_size, bold=True)

    def handle_event(self, event: pygame.event.Event):
        if not self.enabled:
            return
        if event.type == pygame.MOUSEMOTION:
            self._hovered = self.rect.collidepoint(event.pos)
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos) and self.callback:
                self.callback()

    def draw(self, surface: pygame.Surface):
        if not self.enabled:
            col = C["grey_dark"]
            tc  = C["text_dim"]
        elif self._hovered:
            col = self.hover_color
            tc  = self.text_color
        else:
            col = self.color
            tc  = self.text_color

        rounded_rect(surface, col, self.rect, radius=self.radius,
                     border=2, border_color=tc)
        label_surf = self._font.render(self.label, True, tc)
        lx = self.rect.centerx - label_surf.get_width() // 2
        ly = self.rect.centery - label_surf.get_height() // 2
        surface.blit(label_surf, (lx, ly))


# ── Stage Card ────────────────────────────────────────────────────────────────

class StageCard:
    """Visual card representing one production stage."""

    STATUS_COLORS = {
        "pending":     (C["grey"],       C["grey_dark"]),
        "in_progress": (C["yellow"],     C["yellow_dark"]),
        "passed":      (C["green"],      C["green_dark"]),
        "defective":   (C["red"],        C["red_dark"]),
        "skipped":     (C["text_dim"],   C["grey_dark"]),
    }
    STATUS_ICONS = {
        "pending":     "-",
        "in_progress": ">",
        "passed":      "OK",
        "defective":   "!",
        "skipped":     "SK",
    }

    def __init__(self, rect: pygame.Rect, stage_id: int,
                 name: str, description: str):
        self.rect        = rect
        self.stage_id    = stage_id
        self.name        = name
        self.description = description
        self.status      = "pending"
        self.progress    = 0.0
        self.fault_msg   = ""
        self._font_title = pygame.font.SysFont("segoeui", 15, bold=True)
        self._font_body  = pygame.font.SysFont("segoeui", 12)
        self._font_icon  = pygame.font.SysFont("consolas", 20, bold=True)
        self._font_id    = pygame.font.SysFont("segoeui", 28, bold=True)

    def update(self, status: str, progress: float, fault_msg: str = ""):
        self.status    = status
        self.progress  = progress
        self.fault_msg = fault_msg

    def draw(self, surface: pygame.Surface):
        fg, bg = self.STATUS_COLORS.get(self.status, (C["grey"], C["grey_dark"]))

        # Card background
        rounded_rect(surface, C["panel"], self.rect, radius=12,
                     border=2, border_color=fg)

        # Stage number badge
        badge = pygame.Rect(self.rect.x + 8, self.rect.y + 8, 36, 36)
        rounded_rect(surface, bg, badge, radius=6)
        id_surf = self._font_id.render(str(self.stage_id), True, fg)
        surface.blit(id_surf, (badge.centerx - id_surf.get_width()//2,
                               badge.centery - id_surf.get_height()//2))

        # Stage name
        name_surf = self._font_title.render(self.name, True, fg)
        surface.blit(name_surf, (self.rect.x + 52, self.rect.y + 10))

        # Description
        desc_surf = self._font_body.render(self.description, True, C["text_dim"])
        surface.blit(desc_surf, (self.rect.x + 52, self.rect.y + 30))

        # Status icon
        icon = self.STATUS_ICONS.get(self.status, "-")
        icon_surf = self._font_icon.render(icon, True, fg)
        surface.blit(icon_surf, (self.rect.right - 34,
                                 self.rect.y + self.rect.height//2 - icon_surf.get_height()//2))

        # Progress bar (only when in_progress)
        if self.status == "in_progress":
            bar_rect = pygame.Rect(self.rect.x + 8,
                                   self.rect.bottom - 12,
                                   self.rect.width - 16, 6)
            pygame.draw.rect(surface, C["grey_dark"], bar_rect, border_radius=3)
            fill_w = int(bar_rect.width * max(0.0, min(1.0, self.progress)))
            if fill_w > 0:
                fill_rect = pygame.Rect(bar_rect.x, bar_rect.y, fill_w, bar_rect.height)
                pygame.draw.rect(surface, C["yellow"], fill_rect, border_radius=3)

        # Fault message
        if self.fault_msg and self.status == "defective":
            fault_surf = self._font_body.render(
                f"FAULT: {self.fault_msg[:38]}", True, C["red"])
            surface.blit(fault_surf, (self.rect.x + 8, self.rect.bottom - 16))


# ── Stats Panel ───────────────────────────────────────────────────────────────

class StatsPanel:
    def __init__(self, rect: pygame.Rect):
        self.rect       = rect
        self._font_h    = pygame.font.SysFont("segoeui", 14, bold=True)
        self._font_val  = pygame.font.SysFont("consolas", 28, bold=True)
        self._font_lab  = pygame.font.SysFont("segoeui", 12)
        self._font_unit = pygame.font.SysFont("segoeui", 12)

    def draw(self, surface: pygame.Surface, metrics: dict, influx_ok: bool):
        rounded_rect(surface, C["panel"], self.rect, radius=12,
                     border=2, border_color=C["border"])

        title = self._font_h.render("PRODUCTION STATISTICS", True, C["text_dim"])
        surface.blit(title, (self.rect.x + 12, self.rect.y + 10))

        rows = [
            ("Parts OK",       str(metrics.get("parts_produced", 0)),  C["green"]),
            ("Defects",        str(metrics.get("defects_total",  0)),   C["red"]),
            ("Defect Rate",    f"{metrics.get('defect_rate_pct', 0.0):.1f} pct", C["yellow"]),
            ("Cycles Started", str(metrics.get("cycles_started", 0)),   C["blue"]),
            ("Uptime",         f"{int(metrics.get('uptime_seconds',0))}s", C["text"]),
        ]

        y = self.rect.y + 36
        for label, value, color in rows:
            lab_surf = self._font_lab.render(label, True, C["text_dim"])
            val_surf = self._font_val.render(value, True, color)
            surface.blit(lab_surf, (self.rect.x + 12, y))
            surface.blit(val_surf, (self.rect.x + 12, y + 16))
            y += 56

        # InfluxDB status indicator
        dot_color = C["green"] if influx_ok else C["red"]
        status_text = "InfluxDB ●" if influx_ok else "InfluxDB ○ (offline)"
        dot_surf = self._font_lab.render(status_text, True, dot_color)
        surface.blit(dot_surf, (self.rect.x + 12, self.rect.bottom - 24))


# ── Machine State Banner ──────────────────────────────────────────────────────

class StateBanner:
    def __init__(self, rect: pygame.Rect):
        self.rect   = rect
        self._font  = pygame.font.SysFont("segoeui", 20, bold=True)
        self._font2 = pygame.font.SysFont("segoeui", 13)

    def draw(self, surface: pygame.Surface, state: str,
             fault_msg: str, current_stage: str):
        color = C.get(state, C["grey"])
        rounded_rect(surface, C["panel"], self.rect, radius=12,
                     border=2, border_color=color)

        # State label
        state_surf = self._font.render(f"STATE:  {state}", True, color)
        surface.blit(state_surf, (self.rect.x + 16,
                                  self.rect.centery - state_surf.get_height() - 2))

        # Stage or fault
        if fault_msg:
            detail = self._font2.render(f"FAULT: {fault_msg}", True, C["red"])
        else:
            detail = self._font2.render(f"Stage: {current_stage}", True, C["text_dim"])
        surface.blit(detail, (self.rect.x + 16,
                               self.rect.centery + 4))
