"""
influx_client.py
Handles all InfluxDB communication for the Ink Marker Production Line.
Runs writes in a background thread so the HMI loop is never blocked.
"""

import threading
import time
import queue
import logging
import os
from typing import Optional

try:
    from influxdb_client import InfluxDBClient, Point, WritePrecision
    from influxdb_client.client.write_api import SYNCHRONOUS
    INFLUX_AVAILABLE = True
except ImportError:
    INFLUX_AVAILABLE = False
    logging.warning("influxdb-client not installed. Metrics will be logged locally only.")

# ── Configuration ────────────────────────────────────────────────────────────
INFLUX_URL    = os.getenv("INFLUX_URL", "http://localhost:8086")
INFLUX_TOKEN  = os.getenv("INFLUX_TOKEN", "marker_admin_token_2026")
INFLUX_ORG    = os.getenv("INFLUX_ORG", "marker_org")
INFLUX_BUCKET = os.getenv("INFLUX_BUCKET", "marker_production")
MACHINE_ID    = os.getenv("MACHINE_ID", "MARKER_LINE_01")


class InfluxWriter:
    """
    Thread-safe InfluxDB writer.
    Enqueue metric dicts with put(); a background thread drains the queue.
    Falls back to console logging when InfluxDB is unavailable.
    """

    def __init__(self):
        self._queue: queue.Queue = queue.Queue(maxsize=500)
        self._client: Optional[object] = None
        self._write_api: Optional[object] = None
        self._running: bool = False
        self._thread: Optional[threading.Thread] = None
        self._connected: bool = False
        self._connect()

    # ------------------------------------------------------------------ #
    #  Connection                                                          #
    # ------------------------------------------------------------------ #

    def _connect(self):
        if not INFLUX_AVAILABLE:
            logging.info("InfluxDB client library not available — running in offline mode.")
            return
        try:
            self._client = InfluxDBClient(
                url=INFLUX_URL,
                token=INFLUX_TOKEN,
                org=INFLUX_ORG,
                timeout=3_000,   # 3 s connect timeout
            )
            self._write_api = self._client.write_api(write_options=SYNCHRONOUS)
            # Ping to verify connectivity
            self._client.ping()
            self._connected = True
            logging.info("InfluxDB connected at %s", INFLUX_URL)
        except Exception as exc:
            self._connected = False
            logging.warning("InfluxDB not reachable (%s) — running in offline mode.", exc)

    # ------------------------------------------------------------------ #
    #  Public API                                                          #
    # ------------------------------------------------------------------ #

    def start(self):
        """Start the background writer thread."""
        self._running = True
        self._thread = threading.Thread(target=self._worker, daemon=True, name="influx-writer")
        self._thread.start()

    def stop(self):
        """Signal the worker to flush and exit."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)
        if self._client:
            self._client.close()

    def put(self, metrics: dict):
        """
        Enqueue a metrics snapshot for async writing.
        metrics dict keys expected:
          machine_state, parts_produced, defects_total,
          defect_rate_pct, current_stage, uptime_seconds,
          cycles_started, cycle_result (optional)
        """
        try:
            self._queue.put_nowait(metrics)
        except queue.Full:
            logging.warning("InfluxDB write queue full — dropping metric point.")

    @property
    def connected(self) -> bool:
        return self._connected

    # ------------------------------------------------------------------ #
    #  Background Worker                                                   #
    # ------------------------------------------------------------------ #

    def _worker(self):
        while self._running or not self._queue.empty():
            try:
                metrics = self._queue.get(timeout=0.5)
                self._write(metrics)
                self._queue.task_done()
            except queue.Empty:
                continue
            except Exception as exc:
                logging.error("InfluxDB worker error: %s", exc)

    def _write(self, metrics: dict):
        """Build an InfluxDB Point and write it."""
        if not self._connected or not INFLUX_AVAILABLE:
            # Offline fallback — just log
            logging.debug("METRIC (offline): %s", metrics)
            return

        try:
            point = (
                Point("marker_production")
                .tag("machine_id", MACHINE_ID)
                .tag("state", metrics.get("machine_state", "UNKNOWN"))
                .field("parts_produced",   int(metrics.get("parts_produced", 0)))
                .field("defects_total",    int(metrics.get("defects_total", 0)))
                .field("defect_rate_pct",  float(metrics.get("defect_rate_pct", 0.0)))
                .field("uptime_seconds",   float(metrics.get("uptime_seconds", 0.0)))
                .field("cycles_started",   int(metrics.get("cycles_started", 0)))
                .field("current_stage",    str(metrics.get("current_stage", "N/A")))
                .field("machine_state",    str(metrics.get("machine_state", "UNKNOWN")))
                .field("active_fault",     str(metrics.get("active_fault", "")))
            )

            # Optional field — only present on cycle completion
            if "cycle_result" in metrics:
                point = point.field("cycle_result", str(metrics["cycle_result"]))

            self._write_api.write(
                bucket=INFLUX_BUCKET,
                org=INFLUX_ORG,
                record=point,
                write_precision=WritePrecision.S,
            )
        except Exception as exc:
            self._connected = False
            logging.error("InfluxDB write failed: %s — switching to offline mode.", exc)


# ── Module-level singleton ───────────────────────────────────────────────────
_writer: Optional[InfluxWriter] = None


def get_writer() -> InfluxWriter:
    global _writer
    if _writer is None:
        _writer = InfluxWriter()
        _writer.start()
    return _writer


def shutdown():
    global _writer
    if _writer:
        _writer.stop()
        _writer = None
