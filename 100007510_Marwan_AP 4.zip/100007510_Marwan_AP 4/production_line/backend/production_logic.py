"""Backend model for the ink marker manufacturing production line.

The module keeps the simulation independent from Pygame and InfluxDB so it can
be exercised from tests, the HMI, or another interface.
"""

import random
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class MachineState(Enum):
    IDLE = "IDLE"
    RUNNING = "RUNNING"
    STOPPED = "STOPPED"
    FAULTED = "FAULTED"
    EMERGENCY = "EMERGENCY STOP"
    COMPLETE = "CYCLE COMPLETE"


class StageStatus(Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    PASSED = "passed"
    DEFECTIVE = "defective"
    SKIPPED = "skipped"


@dataclass
class Stage:
    id: int
    name: str
    description: str
    duration: float          # seconds to complete this stage
    defect_rate: float       # probability 0.0–1.0 of a defect
    defect_reasons: list     # list of possible fault messages
    status: StageStatus = StageStatus.PENDING
    elapsed: float = 0.0
    fault_message: str = ""
    start_time: float = 0.0

    def reset(self):
        self.status = StageStatus.PENDING
        self.elapsed = 0.0
        self.fault_message = ""
        self.start_time = 0.0

    @property
    def progress(self) -> float:
        """Returns 0.0–1.0 progress through this stage."""
        if self.duration == 0:
            return 1.0
        return min(self.elapsed / self.duration, 1.0)


def build_stages() -> list:
    """Factory function - returns the 5 ink marker production stages."""
    return [
        Stage(
            id=1,
            name="Plastic Barrel Molding",
            description="Mold and cool the plastic marker barrel",
            duration=3.0,
            defect_rate=0.12,
            defect_reasons=[
                "Barrel wall thickness out of tolerance",
                "Mold flash detected on barrel seam",
                "Cooling warp exceeds 0.5mm",
            ],
        ),
        Stage(
            id=2,
            name="Ink Reservoir Filling",
            description="Fill internal reservoir with metered ink volume",
            duration=4.0,
            defect_rate=0.10,
            defect_reasons=[
                "Ink fill volume below specification",
                "Reservoir leak detected",
                "Ink viscosity outside process range",
            ],
        ),
        Stage(
            id=3,
            name="Marker Tip Installation",
            description="Insert and seat fiber tip into barrel nose",
            duration=2.5,
            defect_rate=0.08,
            defect_reasons=[
                "Tip seating depth out of tolerance",
                "Fiber tip misalignment detected",
                "Tip feed channel blockage",
            ],
        ),
        Stage(
            id=4,
            name="Cap Assembly",
            description="Fit cap and verify snap retention force",
            duration=2.0,
            defect_rate=0.07,
            defect_reasons=[
                "Cap retention force below threshold",
                "Cap clip deformation detected",
                "Cap seal not fully engaged",
            ],
        ),
        Stage(
            id=5,
            name="Quality Control",
            description="Automated flow, seal, and visual inspection",
            duration=3.5,
            defect_rate=0.06,
            defect_reasons=[
                "Final QC: ink flow below specification",
                "Final QC: cap seal leakage detected",
                "Final QC: cosmetic defect detected",
            ],
        ),
    ]

@dataclass
class Product:
    """A single ink marker moving through the simulated line."""

    serial_number: int
    current_stage: int = 0
    passed_stages: list[str] = field(default_factory=list)
    rejected: bool = False
    defect_reason: str = ""

    def mark_passed(self, stage: Stage):
        self.current_stage = stage.id
        self.passed_stages.append(stage.name)

    def reject(self, reason: str):
        self.rejected = True
        self.defect_reason = reason


class Machine:
    """Represents the physical machine station performing stage work."""

    def __init__(self, machine_id: str = "MARKER_LINE_01"):
        self.machine_id = machine_id
        self.last_fault = ""

    def process_stage(self, product: Product, stage: Stage) -> tuple[bool, str]:
        """Return whether the product passed the stage and any defect reason."""
        if random.random() < stage.defect_rate:
            reason = random.choice(stage.defect_reasons)
            self.last_fault = reason
            product.reject(reason)
            return False, reason

        product.mark_passed(stage)
        self.last_fault = ""
        return True, ""


class QualityControl:
    """Final inspection logic for completed ink markers."""

    def inspect(self, product: Product, stage: Stage) -> tuple[bool, str]:
        if random.random() < stage.defect_rate:
            reason = random.choice(stage.defect_reasons)
            product.reject(reason)
            return False, reason

        product.mark_passed(stage)
        return True, ""


class ProductionLine:
    """
    Core production line controller.
    Call update(delta_time) every frame from the HMI loop.
    """

    def __init__(self):
        self.stages: list[Stage] = build_stages()
        self.state: MachineState = MachineState.IDLE
        self.current_stage_index: int = 0
        self.machine = Machine()
        self.quality_control = QualityControl()
        self.current_product: Optional[Product] = None

        # Counters
        self.parts_produced: int = 0
        self.defects_total: int = 0
        self.cycles_started: int = 0
        self._next_serial_number: int = 1

        # Timing
        self.session_start: float = time.time()
        self.uptime_seconds: float = 0.0
        self.last_update: float = time.time()

        # Current cycle fault info
        self.active_fault: str = ""
        self.last_completed_part: Optional[str] = None   # "OK" or "DEFECT"

        # Metrics history for InfluxDB (ring buffer, last 200 entries)
        self._metrics_history: list[dict] = []

    # ------------------------------------------------------------------ #
    #  Control Methods (called by HMI buttons)                            #
    # ------------------------------------------------------------------ #

    def start(self):
        if self.state == MachineState.IDLE:
            self._begin_cycle()
        elif self.state == MachineState.STOPPED:
            self.state = MachineState.RUNNING
            self.active_fault = ""
            if self.current_stage and self.current_stage.status != StageStatus.IN_PROGRESS:
                self._begin_stage(self.current_stage_index)
        elif self.state == MachineState.COMPLETE:
            self.start_new_cycle()

    def stop(self):
        if self.state == MachineState.RUNNING:
            self.state = MachineState.STOPPED

    def reset(self):
        """Full operator reset: clear counters, product state, and stages."""
        self.state = MachineState.IDLE
        self.parts_produced = 0
        self.defects_total = 0
        self.cycles_started = 0
        self.uptime_seconds = 0.0
        self._next_serial_number = 1
        self._metrics_history.clear()
        self._reset_for_next_cycle()

    def _reset_for_next_cycle(self):
        """Clear transient stage/product state without changing counters."""
        self.current_stage_index = 0
        self.active_fault = ""
        self.last_completed_part = None
        self.current_product = None
        for stage in self.stages:
            stage.reset()

    def emergency_stop(self):
        self.state = MachineState.EMERGENCY
        self.active_fault = "EMERGENCY STOP ACTIVATED — Reset required"
        # Mark in-progress stage as faulted
        if self.current_stage_index < len(self.stages):
            s = self.stages[self.current_stage_index]
            if s.status == StageStatus.IN_PROGRESS:
                s.status = StageStatus.DEFECTIVE
                s.fault_message = "Interrupted by E-Stop"

    # ------------------------------------------------------------------ #
    #  Update Loop                                                         #
    # ------------------------------------------------------------------ #

    def update(self, delta: float):
        """
        Advance simulation by `delta` seconds.
        Call this every Pygame frame: update(clock.get_time() / 1000.0)
        """
        if self.state != MachineState.RUNNING:
            return

        if self.current_product is None:
            self._begin_cycle()

        self.uptime_seconds += delta

        stage = self.stages[self.current_stage_index]

        if stage.status == StageStatus.IN_PROGRESS:
            stage.elapsed += delta

            if stage.elapsed >= stage.duration:
                self._finish_stage(stage)

    # ------------------------------------------------------------------ #
    #  Internal Helpers                                                    #
    # ------------------------------------------------------------------ #

    def _begin_stage(self, index: int):
        if index >= len(self.stages):
            return
        stage = self.stages[index]
        stage.status = StageStatus.IN_PROGRESS
        stage.start_time = time.time()
        stage.elapsed = 0.0

    def _begin_cycle(self):
        self._reset_for_next_cycle()
        self.current_product = Product(serial_number=self._next_serial_number)
        self._next_serial_number += 1
        self.cycles_started += 1
        self.state = MachineState.RUNNING
        self._begin_stage(0)

    def _finish_stage(self, stage: Stage):
        """Called when a stage timer completes. Run defect check."""
        if self.current_product is None:
            self._begin_cycle()

        if stage.name == "Quality Control":
            passed, reason = self.quality_control.inspect(self.current_product, stage)
        else:
            passed, reason = self.machine.process_stage(self.current_product, stage)

        if not passed:
            stage.status = StageStatus.DEFECTIVE
            stage.fault_message = reason
            self.active_fault = f"Stage {stage.id} — {stage.fault_message}"
            self.defects_total += 1
            self.last_completed_part = "DEFECT"
            self.state = MachineState.FAULTED
            self._record_metrics(defect=True)
        else:
            stage.status = StageStatus.PASSED
            stage.fault_message = ""
            next_index = self.current_stage_index + 1

            if next_index >= len(self.stages):
                # All stages passed — marker complete
                self.parts_produced += 1
                self.last_completed_part = "OK"
                self.state = MachineState.COMPLETE
                self._record_metrics(defect=False)
            else:
                self.current_stage_index = next_index
                self._begin_stage(self.current_stage_index)

    def acknowledge_fault(self):
        """
        After a FAULTED state the operator presses Start to acknowledge
        and resume from the next stage (defective part is discarded).
        """
        if self.state == MachineState.FAULTED:
            self._reset_for_next_cycle()
            self.state = MachineState.IDLE

    def start_new_cycle(self):
        """Called automatically after COMPLETE to begin next marker."""
        if self.state == MachineState.COMPLETE:
            self._begin_cycle()

    # ------------------------------------------------------------------ #
    #  Metrics                                                             #
    # ------------------------------------------------------------------ #

    def get_metrics(self) -> dict:
        """Returns a snapshot dict suitable for InfluxDB write."""
        defect_rate = 0.0
        if self.cycles_started > 0:
            defect_rate = round(self.defects_total / max(self.cycles_started, 1) * 100, 2)

        current_stage_name = "N/A"
        if self.current_stage_index < len(self.stages):
            current_stage_name = self.stages[self.current_stage_index].name

        metrics = {
            "machine_state": self.state.value,
            "parts_produced": self.parts_produced,
            "defects_total": self.defects_total,
            "defect_rate_pct": defect_rate,
            "cycles_started": self.cycles_started,
            "current_stage": current_stage_name,
            "uptime_seconds": round(self.uptime_seconds, 1),
            "active_fault": self.active_fault,
        }
        if self.last_completed_part:
            metrics["cycle_result"] = self.last_completed_part
        return metrics

    def _record_metrics(self, defect: bool):
        snapshot = self.get_metrics()
        snapshot["timestamp"] = time.time()
        snapshot["cycle_result"] = "DEFECT" if defect else "OK"
        self._metrics_history.append(snapshot)
        if len(self._metrics_history) > 200:
            self._metrics_history.pop(0)

    @property
    def current_stage(self) -> Optional[Stage]:
        if 0 <= self.current_stage_index < len(self.stages):
            return self.stages[self.current_stage_index]
        return None

    @property
    def defect_rate(self) -> float:
        if self.cycles_started == 0:
            return 0.0
        return round(self.defects_total / self.cycles_started * 100, 1)
