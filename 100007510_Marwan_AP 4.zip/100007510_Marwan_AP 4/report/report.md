# Ink Marker Manufacturing Production Line Simulation

**Student:** Marwan Ahmed  
**Student ID:** 100007510  
**University:** SRH Fernhochschule  
**Course:** Advanced Programming Project  
**Project:** 100007510_Marwan_AP  
**Date:** June 2026

---

## 1. Introduction

This project implements a simulated Industry 4.0 ink marker manufacturing production line. The system models the manufacturing flow from plastic barrel molding to final quality control and provides a human-machine interface, production statistics, defect handling, telemetry logging, and dashboard monitoring.

The goal is to demonstrate advanced programming concepts in a practical manufacturing scenario. The project uses object-oriented design, a finite-state production controller, event-driven Pygame interaction, background telemetry writing, Docker-based infrastructure, and static web documentation.

Repository: 100007510_Marwan_AP

---

## 2. Product and Production Concept

The simulated product is an ink marker consisting of a molded plastic barrel, filled ink reservoir, installed fiber tip, and protective cap. A complete marker must pass five sequential manufacturing stages:

| Stage | Name | Purpose | Duration | Defect Rate |
|---|---|---|---:|---:|
| 1 | Plastic Barrel Molding | Mold and cool the plastic marker barrel | 3.0 s | 12% |
| 2 | Ink Reservoir Filling | Fill the internal reservoir with metered ink volume | 4.0 s | 10% |
| 3 | Marker Tip Installation | Insert and seat the fiber tip into the barrel nose | 2.5 s | 8% |
| 4 | Cap Assembly | Fit the cap and verify snap retention force | 2.0 s | 7% |
| 5 | Quality Control | Inspect ink flow, cap seal, dimensions, and appearance | 3.5 s | 6% |

Each stage has a fixed processing time and a configurable probability of failure. When a defect is detected, the machine enters a faulted state and displays a specific fault message.

---

## 3. Implementation

### 3.1 Architecture

The project is divided into three layers:

```text
HMI Layer        production_line/hmi/
Backend Layer    production_line/backend/
Monitoring       InfluxDB + Grafana provisioning
```

This separation keeps the simulation logic independent from the graphical interface and telemetry infrastructure.

### 3.2 Backend Design

The backend is implemented in `production_line/backend/production_logic.py` and uses object-oriented classes:

- `Product` represents one ink marker travelling through the line.
- `Machine` represents the processing equipment and performs stage-level defect checks.
- `QualityControl` performs the final inspection stage.
- `ProductionLine` coordinates machine state, stage progression, counters, and metrics.
- `Stage` stores timing, defect rate, status, and fault-message data.

The `ProductionLine` class implements a finite-state machine with the states:

- `IDLE`
- `RUNNING`
- `STOPPED`
- `FAULTED`
- `EMERGENCY STOP`
- `CYCLE COMPLETE`

The HMI calls `ProductionLine.update(delta)` every frame. This design decouples simulation timing from frame rate and keeps the backend testable without Pygame.

### 3.3 Defect Detection and Quality Control

Defect detection is stochastic. At the end of each stage, the machine compares a random value against the stage's configured defect rate. If the stage fails, the current product is rejected, the defect counter increases, and a human-readable fault message is displayed.

The final stage is handled by the `QualityControl` class to make the quality inspection responsibility explicit and separate from normal production stages.

### 3.4 Pygame HMI

The HMI is implemented in `production_line/hmi/main.py` and `production_line/hmi/ui_components.py`.

It includes:

- Start button
- Stop button
- Reset button
- Emergency Stop button
- Machine state display
- Five production stage cards
- Progress bars for active stages
- Production statistics panel
- Defect tracking and defect messages
- Keyboard shortcuts for all major actions

The application launches with:

```bash
python production_line/hmi/main.py
```

The import path is configured so the command works from the project root on macOS, Windows, and Linux.

### 3.5 InfluxDB Integration

Telemetry is handled by `production_line/backend/influx_client.py`. The HMI periodically enqueues metric snapshots. A background thread writes them to InfluxDB so database communication does not block the Pygame event loop.

Metrics include:

- `parts_produced`
- `defects_total`
- `defect_rate_pct`
- `current_stage`
- `machine_state`
- `uptime_seconds`
- `cycles_started`
- `active_fault`

If InfluxDB is unavailable, the application continues running and reports telemetry as offline.

### 3.6 Grafana Dashboard

Grafana provisioning files are stored in `grafana/provisioning/`.

The dashboard contains:

- Parts Produced
- Total Defects
- Defect Rate
- Machine State
- Current Stage
- Production Trend
- Defect Trend
- Production Log

The datasource uses the Docker service URL `http://influxdb:8086` and the configured InfluxDB organization and bucket.

### 3.7 Docker

Docker Compose starts the monitoring stack:

```bash
docker compose up -d
```

The default services are:

- InfluxDB 2.7
- Grafana 10.4

The Pygame app is available as an optional Compose profile because native desktop windows differ between operating systems:

```bash
docker compose --profile hmi up --build app
```

---

## 4. Screenshots

### 4.1 HMI Main Screen

![Pygame HMI main idle screen](../website/screenshots/hmi_main.png)

The main screen shows the machine in the `IDLE` state, all five production stages, production counters, and operator controls.

### 4.2 HMI Running State

![Pygame HMI running state](../website/screenshots/hmi_running.png)

The running state shows an active production stage with progress, enabled Stop and Emergency Stop controls, and live production statistics.

### 4.3 HMI Fault State

![Pygame HMI fault state](../website/screenshots/fault_state.png)

The fault state shows defect detection, a fault message, defect counter updates, and reset/recovery controls.

### 4.4 Grafana Dashboard

![Representative Grafana dashboard layout](../website/screenshots/grafana_dashboard.png)

This image is a representative dashboard layout for documentation purposes when Docker/Grafana is not available in the execution environment. The real dashboard is provisioned automatically from `grafana/provisioning/dashboards/marker_production.json` when the monitoring stack is started with `docker compose up -d`.

---

## 5. Tools Used

### Python

Python is used for the simulation backend, HMI orchestration, and telemetry integration.

### Pygame

Pygame provides the graphical HMI, event loop, button handling, keyboard shortcuts, and real-time drawing.

### InfluxDB

InfluxDB stores time-series production metrics.

### Grafana

Grafana visualizes live production and quality data through an automatically provisioned dashboard.

### Docker

Docker Compose provides reproducible infrastructure for InfluxDB and Grafana.

### GitHub and GitHub Pages

GitHub hosts the repository when published. The `website/` folder contains the static project website.

---

## 6. Evaluation

### Strengths

The project demonstrates a clear separation of concerns between backend logic, user interface, and monitoring infrastructure. The backend is object-oriented and can be extended with additional machines, product variants, or quality rules. The Pygame HMI provides an understandable operator interface with industrial-style state feedback. InfluxDB and Grafana add realistic telemetry and visualization features.

### Limitations

The simulation uses probabilistic defects rather than real sensor data. Stage durations are fixed, and the current model processes one product at a time. A real factory system would require hardware interfaces, authentication, audit logging, alarm management, and more robust persistence.

### Future Improvements

- Add unit tests for state transitions and defect handling.
- Add multiple parallel production lines.
- Implement configurable production recipes.
- Add shift-based reporting.
- Export daily production summaries.
- Replace stochastic inspection with image-based quality control.

---

## 7. Conclusion

The finished project satisfies the Advanced Programming assignment by combining object-oriented Python design, event-driven programming, containerized services, telemetry logging, and technical documentation. It is runnable locally on major desktop operating systems and includes a Docker-based monitoring stack for InfluxDB and Grafana.

The result is a complete academic simulation of an ink marker manufacturing production line with a functional HMI, realistic defect handling, and live production monitoring.

---

## 8. References

- Python documentation: <https://docs.python.org/3/>
- Pygame documentation: <https://www.pygame.org/docs/>
- InfluxDB documentation: <https://docs.influxdata.com/>
- Grafana documentation: <https://grafana.com/docs/>
- Docker documentation: <https://docs.docker.com/>

---

## Appendix A: AI Tool Usage

AI tools were used during development as support tools, not as a replacement for engineering review.

### Google Gemini

Gemini was used for early architecture brainstorming, especially for translating a game-style Pygame loop into a production-line simulation. It helped outline possible stage names, dashboard panels, and documentation sections.

Human corrections included separating the code into backend/HMI/monitoring layers, improving Docker networking, and validating the state machine transitions.

### GitHub Copilot

GitHub Copilot was used for inline code completions, especially for repetitive dictionary construction, UI widget boilerplate, and comments. Suggestions were reviewed before acceptance.

Corrections included fixing incorrect attribute names, avoiding blocking database writes on the Pygame loop, and aligning generated snippets with the actual class structure.

### Final Review

All AI-assisted output was manually reviewed, edited, and tested. The final project structure, code behavior, Docker configuration, website, README, and report were finalized by human-directed engineering review.
